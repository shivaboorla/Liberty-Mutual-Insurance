import { Component } from '@angular/core';
import { MaterialModule } from '../material/material.module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  imports: [MaterialModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent {
  // @Output() menuToggled = new EventEmitter<boolean>();
  user: string = '';

  constructor(private router: Router) {}

  logout(): void {
    this.router.navigate(['/login']);
    console.log('Logged out');
  }
}
