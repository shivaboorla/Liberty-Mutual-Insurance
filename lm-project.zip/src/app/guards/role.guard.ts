import { CanActivateFn } from '@angular/router';

export const roleGuard: CanActivateFn = (route, state) => {
  return true;
};

// src/app/role.guard.ts
import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
} from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class RoleGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    const expectedRole = route.data['expectedRole'];
    const token = localStorage.getItem('jwtToken');
    if (token) {
      // Decode token (simple implementation; consider using a library for production)
      const tokenPayload = JSON.parse(atob(token.split('.')[1]));
      if (tokenPayload.role === expectedRole) {
        return true;
      }
    }
    this.router.navigate(['/login']);
    return false;
  }
}
