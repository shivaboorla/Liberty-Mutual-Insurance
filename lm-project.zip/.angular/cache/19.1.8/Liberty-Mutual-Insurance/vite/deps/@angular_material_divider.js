import {
  MatDivider,
  MatDividerModule
} from "./chunk-UGRZ2RCP.js";
import "./chunk-MRESFXTS.js";
import "./chunk-WOJXUJYL.js";
import "./chunk-ZK5O5OQ2.js";
import "./chunk-3PR72SV2.js";
import "./chunk-ZSNVYD2F.js";
import "./chunk-BRWGVVXZ.js";
export {
  MatDivider,
  MatDividerModule
};
