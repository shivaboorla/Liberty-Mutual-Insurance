import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-KTGGWSYW.js";
import "./chunk-ATW4ADLA.js";
import "./chunk-WRFF4IR7.js";
import "./chunk-LQDIXU4Y.js";
import "./chunk-UGKVFNC3.js";
import "./chunk-BGILPUG2.js";
import "./chunk-CH64OKJE.js";
import "./chunk-YHCV7DAQ.js";
export {
  MatDivider,
  MatDividerModule
};
