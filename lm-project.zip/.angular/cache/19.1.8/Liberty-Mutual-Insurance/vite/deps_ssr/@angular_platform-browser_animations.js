import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-75TVJC6E.js";
import "./chunk-A3VLLWQK.js";
import "./chunk-3TI32C3L.js";
import "./chunk-IU6WKZPY.js";
import "./chunk-TQLFOCE7.js";
import "./chunk-BGILPUG2.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-CH64OKJE.js";
import "./chunk-YHCV7DAQ.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
